console.log('Script starting...');
console.log('Hello, World!');
console.log('Script finished.');
